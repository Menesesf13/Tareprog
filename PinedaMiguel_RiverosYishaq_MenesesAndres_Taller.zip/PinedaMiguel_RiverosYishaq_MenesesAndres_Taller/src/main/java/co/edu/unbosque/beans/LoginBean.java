package co.edu.unbosque.beans;


import co.edu.unbosque.controller.HttpClientSynchronous;
import co.edu.unbosque.util.AESUtil;
import jakarta.annotation.ManagedBean;
import jakarta.enterprise.context.RequestScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;

@ManagedBean
@RequestScoped
public class LoginBean {

	private String nombre;
	private String nota1;
	private String nota2;
	private String nota3;
	private String output;
	
	public void showSticky(String message, FacesMessage.Severity severity) {
        FacesContext.getCurrentInstance().addMessage("createButton",
                new FacesMessage(severity, "Sticky Message", message));
    }



	public void calcularPromedio() {
		try {
			String url = "http://localhost:8081/notas/createnotasjson";
			String requestBody = "{\"nombre\":\"" + AESUtil.encrypt(nombre) + "\",\"nota1\":\"" + AESUtil.encrypt(nota1)
					+ "\",\"nota2\":\"" + AESUtil.encrypt(nota2) + "\",\"nota3\":\"" + AESUtil.encrypt(nota3) + "\"}";
			String response = HttpClientSynchronous.doPost(url, requestBody);
			if (response.startsWith("Muy")) {
				showSticky(response, FacesMessage.SEVERITY_INFO);
			} else if (response.startsWith("Estas")) {
				showSticky(response, FacesMessage.SEVERITY_ERROR);
			} else if (response.startsWith("Lo")) {
				showSticky(response, FacesMessage.SEVERITY_WARN);
			} else {
				showSticky("Unexpected response: " + response, FacesMessage.SEVERITY_ERROR);
			}
		} catch (Exception e) {
			e.printStackTrace();
			showSticky("Error during validation", FacesMessage.SEVERITY_ERROR);
		}
	}

	public void show() {
		String url = "http://localhost:8081/student/getallstudent";
		String response = HttpClientSynchronous.doGet(url);
		output = response;

	}
	
	public LoginBean() {
	}
	
	

	public String getNombre() {
		return nombre;
	}



	public void setNombre(String nombre) {
		this.nombre = nombre;
	}



	public String getNota1() {
		return nota1;
	}



	public void setNota1(String nota1) {
		this.nota1 = nota1;
	}



	public String getNota2() {
		return nota2;
	}



	public void setNota2(String nota2) {
		this.nota2 = nota2;
	}



	public String getNota3() {
		return nota3;
	}



	public void setNota3(String nota3) {
		this.nota3 = nota3;
	}



	public void addMessage(FacesMessage.Severity severity, String summary, String detail) {
		FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(severity, summary, detail));
	}

	public void showSticky() {
		FacesContext.getCurrentInstance().addMessage("sticky-key",new FacesMessage(
				FacesMessage.SEVERITY_INFO, 
				"Sticky Message", 
				"Message Content")
		);
	}

	public void validate() {
		showSticky();
	}
	
	public void matchPasswords() {
		
	}
}
