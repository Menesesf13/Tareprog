package co.edu.unbosque;

import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

public class ServletInitialization extends SpringBootServletInitializer{

	
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(NotaFinal.class);
	}
}
