package co.edu.unbosque.TallerSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TallerSpringBootEncriptadoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TallerSpringBootEncriptadoApplication.class, args);
	}

}
