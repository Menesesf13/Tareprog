package co.edu.unbosque.configuration;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import co.edu.unbosque.model.Notas;
import co.edu.unbosque.repository.NotasRepository;
import co.edu.unbosque.util.AESUtil;

@Configuration
public class LoadDataBase {
	private static final Logger LOG = LoggerFactory.getLogger(LoadDataBase.class);

	@Bean
	CommandLineRunner initDataBase(NotasRepository notRep) {
		return args -> {
			Optional<Notas> found = notRep.findByName("plato1");
			if (found.isPresent()) {
				LOG.info("Admin already exists, skipping plato creation");
			} else {
				notRep.save(new Notas(AESUtil.encrypt("admin"), AESUtil.encrypt("5"), AESUtil.encrypt("5"),
						AESUtil.encrypt("5"),AESUtil.encrypt("5")));
				LOG.info("pre-loading admin plato");
			}
		};
	}

}
