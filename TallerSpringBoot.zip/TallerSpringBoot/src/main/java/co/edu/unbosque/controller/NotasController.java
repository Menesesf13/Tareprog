package co.edu.unbosque.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import co.edu.unbosque.model.Notas;
import co.edu.unbosque.service.NotasService;
import co.edu.unbosque.util.AESUtil;
import jakarta.transaction.Transactional;

@RestController
@RequestMapping("/Notas")
@CrossOrigin(origins = { "http://localhost:8080", "http://localhost:8081", "*" })
@Transactional
public class NotasController {
	@Autowired
	private NotasService scoServ;
	
	public NotasController() {
	}
	
	@PostMapping(path = "/createnotasjson", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> newUserWithJson(@RequestBody Notas newNotas) {
		Notas temp = new Notas(AESUtil.decryptt(newNotas.getName()), AESUtil.decryptt(newNotas.getcorte1()),
				AESUtil.decryptt(newNotas.getcorte2()), AESUtil.decryptt(newNotas.getcorte3()), null);
		
		int status = scoServ.create(newNotas);
		if (status == 0) {
			double n = Double.parseDouble(scoServ.nota(temp));
			
			if (n > 3) {
				return new ResponseEntity<String>("Muy bien " + n, HttpStatus.CREATED);
			} else if (n == 3) {
				return new ResponseEntity<String>("Estas en lo mas razo " + n, HttpStatus.CREATED);
			} else {
				return new ResponseEntity<String>("lo siento perdiste " + n, HttpStatus.CREATED);
			}
		} else if (status == 1) {
			return new ResponseEntity<>("Error: Usuario ya creado", HttpStatus.CONFLICT);
		} else {
			return new ResponseEntity<>("Error haz un usuario", HttpStatus.NOT_ACCEPTABLE);
		}
			
	}
	
	
	@GetMapping(path = "/getallnotas")
	public ResponseEntity<List<Notas>> getAll() {
		List<Notas> users = scoServ.getAll();
		if (users.isEmpty()) {
			return new ResponseEntity<List<Notas>>(users, HttpStatus.NO_CONTENT);
		} else {
			return new ResponseEntity<List<Notas>>(users, HttpStatus.ACCEPTED);
		}
	}
}
