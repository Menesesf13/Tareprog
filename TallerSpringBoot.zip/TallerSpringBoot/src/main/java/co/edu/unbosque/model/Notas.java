package co.edu.unbosque.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "notas")
public class Notas {

	private @Id @GeneratedValue(strategy = GenerationType.IDENTITY) Long id;
	private String name;
	private String corte1;
	private String corte2;
	private String corte3;
	private String prom;
 
	public Notas( String name, @NotNull String corte1, @NotNull String corte2,@NotNull  String corte3, @NotNull String prom) {
		super();
		
		this.name = name;
		this.corte1 = corte1;
		this.corte2 = corte2;
		this.corte3 = corte3;
		this.prom = prom;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getcorte1() {
		return corte1;
	}

	public void setcorte1(String corte1) {
		this.corte1 = corte1;
	}

	public String getcorte2() {
		return corte2;
	}

	public void setcorte2(String corte2) {
		this.corte2 = corte2;
	}

	public String getcorte3() {
		return corte3;
	}

	public void setcorte3(String corte3) {
		this.corte3 = corte3;
	}

	public String getProm() {
		return prom;
	}

	public void setProm(String prom) {
		this.prom = prom;
	}

	@Override
	public String toString() {
		return "Score [id=" + id + ", name=" + name + ", corte1=" + corte1 + ", corte2=" + corte2
				+ ", corte3=" + corte3 + ", prom=" + prom + "]";
	}
	
	public Notas() {
	}

}
