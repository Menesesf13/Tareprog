package co.edu.unbosque.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.edu.unbosque.model.Notas;
import co.edu.unbosque.repository.NotasRepository;
import co.edu.unbosque.util.AESUtil;

@Service
public class NotasService implements CRUDOperation<Notas> {

	@Autowired
	private NotasRepository scoRepo;
	
	public NotasService() {
	}
	
	@Override
	public int create(Notas data) {
		if (findNameAlreadyTaken(data)) {
			return 1;

		} else {
			String r = nota(data);
			Notas temp = new Notas(AESUtil.encrypt(data.getName()), AESUtil.encrypt(data.getcorte1()),
					AESUtil.encrypt(data.getcorte2()), AESUtil.encrypt(data.getcorte3()), AESUtil.encrypt(r));
			scoRepo.save(temp);
		}
		return 0;
	}

	@Override
	public List<Notas> getAll() {
		List<Notas> database = scoRepo.findAll();
		List<Notas> decrypted = new ArrayList<>();

		for (Notas data : database) {
			Notas newS = new Notas();
			newS.setId(data.getId());
			newS.setName(AESUtil.decrypt(data.getName()));
			newS.setcorte1(AESUtil.decrypt(data.getcorte1()));
			newS.setcorte2(AESUtil.decrypt(data.getcorte2()));
			newS.setcorte3(AESUtil.decrypt(data.getcorte3()));
			newS.setProm(AESUtil.decrypt(data.getProm()));
			decrypted.add(newS);
		}

		return decrypted;
	}

	@Override
	public int deleteById(Long id) {
		Optional<Notas> found = scoRepo.findById(id);
		if (found.isPresent()) {
			scoRepo.delete(found.get());
			return 0;
		} else {
			return 1;
		}
	}

	@Override
	public int update(Long id, Notas newNotas) {
		Optional<Notas> found = scoRepo.findById(id);
		Optional<Notas> newFound = scoRepo.findByName(newNotas.getName());
		if (found.isPresent() && !newFound.isPresent()) {
			Notas temp = found.get();
			temp.setName(AESUtil.encrypt(newNotas.getName()));
			temp.setcorte1(AESUtil.encrypt(newNotas.getcorte1()));
			temp.setcorte2(AESUtil.encrypt(newNotas.getcorte2()));
			temp.setcorte3(AESUtil.encrypt(newNotas.getcorte3()));
			scoRepo.save(temp);
			return 0;
		} else if (found.isPresent() && newFound.isPresent()) {
			return 1;
		} else if (!found.isEmpty()) {
			return 2;
		} else {
			return 3;
		}

	}

	@Override
	public long count() {
		return scoRepo.count();
	}

	@Override
	public boolean exists(Long id) {

		return scoRepo.existsById(id) ? true : false;
	}

	public boolean findNameAlreadyTaken(Notas newNotas) {
		String encryptedUsername = AESUtil.encrypt(newNotas.getName());
		Optional<Notas> found = scoRepo.findByName(encryptedUsername);
		if (found.isPresent()) {
			return true;
		} else {
			return false;
		}
	}

	public String nota(Notas newNotas) {
		try {
			String corte1 = newNotas.getcorte1();
			String corte2 = newNotas.getcorte2();
			String corte3 = newNotas.getcorte3();
			double nota1 = Double.parseDouble(corte1) * 0.30;
			double nota2 = Double.parseDouble(corte2) * 0.30;
			double nota3 = Double.parseDouble(corte3) * 0.40;
			double notaFinal = nota1 + nota2 + nota3;
			
			String n = String.valueOf(notaFinal);
			return n;
		} catch (NumberFormatException e) {
			return "Hay un error en tus notas";
		}
	}

}	