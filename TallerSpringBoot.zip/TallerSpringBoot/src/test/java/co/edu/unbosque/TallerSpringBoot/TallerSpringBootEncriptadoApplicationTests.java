package co.edu.unbosque.TallerSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TallerSpringBootEncriptadoApplicationTests {

	@Test
	void contextLoads() {
	}

}
